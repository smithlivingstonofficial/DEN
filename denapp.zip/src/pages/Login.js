import React from "react";
import { useNavigate } from "react-router-dom";
import { auth, provider, signInWithPopup, db, doc, setDoc, getDoc } from "../firebaseConfig";
import { Container, Typography, Button, Box } from "@mui/material";

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Store user data in local storage
      localStorage.setItem("user", JSON.stringify(user));

      // Check if the user profile already exists in Firestore
      const userDocRef = doc(db, "users", user.uid);
      const userDocSnap = await getDoc(userDocRef);

      if (!userDocSnap.exists()) {
        await setDoc(userDocRef, {
          name: user.displayName,
          email: user.email,
          photoURL: user.photoURL,
          profileComplete: false,
        });
      }

      navigate("/home");  // Redirect to home
    } catch (error) {
      console.error("Login Error:", error);
    }
  };

  return (
    <Container maxWidth="sm" style={{ marginTop: "100px" }}>
      <Box textAlign="center">
        <Typography variant="h4" gutterBottom>
          Login
        </Typography>
        <Button variant="contained" color="primary" onClick={handleLogin}>
          Sign in with Google
        </Button>
      </Box>
    </Container>
  );
};

export default Login;
