import React from "react";

const Emergency = () => {
  return <h1>Emergency Page</h1>;
};

export default Emergency;
