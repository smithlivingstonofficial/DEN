import React, { useEffect, useState, useCallback } from "react";
import { auth, db, doc, getDoc } from "../firebaseConfig";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import { Container, Alert, Button, Box, CircularProgress, Typography } from "@mui/material";
import LocationOnIcon from '@mui/icons-material/LocationOn'; // Optional, for visual indication of location

const mapContainerStyle = { height: "100%", width: "100%" };
const defaultCenter = { lat: 0, lng: 0 }; // Default center (0,0) when location is not available

const Home = () => {
  const [user, setUser] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [location, setLocation] = useState(null);
  const [locationLoading, setLocationLoading] = useState(true); // Add a loading state for location
  const [locationError, setLocationError] = useState(null); // Add an error state for location
  const navigate = useNavigate();

  useEffect(() => {
    const checkUserProfile = async () => {
      const currentUser = auth.currentUser;
      if (!currentUser) {
        navigate("/");
        return;
      }

      setUser(currentUser);
      const userDocRef = doc(db, "users", currentUser.uid);
      const userDocSnap = await getDoc(userDocRef);

      if (userDocSnap.exists() && !userDocSnap.data().profileComplete) {
        setShowPopup(true);
      }
    };

    checkUserProfile();
  }, [navigate]);

  useEffect(() => {
    if (navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          console.log("New location:", newLocation);
          setLocation(newLocation);
          setLocationLoading(false);  // Location found, stop loading
        },
        (error) => {
          console.error("Error getting location:", error);
          setLocationError(error.message); // Store the error message
          setLocationLoading(false);  // Stop loading even on error
        },
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );

      return () => navigator.geolocation.clearWatch(watchId);
    } else {
      console.error("Geolocation is not supported by this browser.");
      setLocationError("Geolocation is not supported."); // Set a specific error message
      setLocationLoading(false); // Stop loading
    }
  }, []);

  const onLoad = useCallback(function callback(map) {
    console.log("Map loaded successfully");
  }, []);

  const onUnmount = useCallback(function callback(map) {
    console.log("Map unmounted");
  }, []);

  return (
    <Container sx={{ mt: 4, height: '100vh', padding: 0 }}>
      <Navbar user={user} />

      {showPopup && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Your profile is incomplete! Please complete it.
          <Button onClick={() => navigate("/profile")} color="primary" sx={{ ml: 2 }}>
            Complete Profile
          </Button>
        </Alert>
      )}

      <LoadScript googleMapsApiKey="YOUR_API_KEY"> {/* Replace with your actual API key */}
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={location || defaultCenter}
          zoom={15}
          onLoad={onLoad}
          onUnmount={onUnmount}
        >
          {location && <Marker position={location} />}
        </GoogleMap>
      </LoadScript>

      <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        {locationLoading && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CircularProgress size={20} />
            <Typography variant="body2">Determining your location...</Typography>
          </Box>
        )}
        {locationError && (
          <Alert severity="error">
            <Typography variant="body2">Error getting location: {locationError}</Typography>
          </Alert>
        )}
        {!locationLoading && !locationError && !location && (  // Indicate if location could not be determined even after loading
          <Alert severity="info">
            Location services may be disabled or unavailable.
          </Alert>
        )}
      </Box>
    </Container>
  );
};

export default Home;