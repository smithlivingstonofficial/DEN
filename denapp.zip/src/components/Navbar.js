import React from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebaseConfig";
import { AppBar, Toolbar, Typography, Button, Avatar, Box, IconButton } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu'; // Optional, for mobile menu

const Navbar = ({ user }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    auth.signOut();
    localStorage.removeItem("user");
    navigate("/");
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: "#1976d2" }}> {/*  Or any desired primary color */}
      <Toolbar>
        {/* Optional:  Add a menu icon for mobile */}
        {/* <IconButton
          size="large"
          edge="start"
          color="inherit"
          aria-label="menu"
          sx={{ mr: 2, display: { xs: 'block', md: 'none' } }} // Hide on larger screens
        >
          <MenuIcon />
        </IconButton> */}

        <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: "bold" }}>
          DEN
        </Typography>

        {user && (
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <IconButton onClick={() => navigate("/profile")}>
              <Avatar alt="Profile" src={user.photoURL || "https://via.placeholder.com/40"} />
            </IconButton>

            <Button variant="contained" color="secondary" onClick={handleLogout}>
              Logout
            </Button>
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;