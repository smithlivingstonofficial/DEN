// TestMapComponent.js
import React, { useCallback } from "react";
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const mapContainerStyle = { height: "100vh", width: "100%" };
const defaultCenter = { lat: 0, lng: 0 }; // Default center (0,0) when location is not available

const TestMapComponent = () => {

    const onLoad = useCallback(function callback(map) {
        console.log("Map loaded successfully");
    }, []);

    const onUnmount = useCallback(function callback(map) {
        console.log("Map unmounted");
    }, []);

    return (
        <LoadScript googleMapsApiKey="AIzaSyCdDETf4E9vOyzdafPdHad2S_pp1O9-Bzk">
            <GoogleMap
                mapContainerStyle={mapContainerStyle}
                center={defaultCenter}
                zoom={15}
                onLoad={onLoad}
                onUnmount={onUnmount}
            >
            </GoogleMap>
        </LoadScript>
    );
}

export default TestMapComponent;