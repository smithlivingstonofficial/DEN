import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, firestore, storage, realtimeDb } from '../../firebaseConfig'; // Adjust the import path as necessary
import { collection, doc, setDoc, onSnapshot } from 'firebase/firestore'; // Import Firestore methods

const Profile = ({ isFirstLogin, userDetails }) => {
    const navigate = useNavigate();
    const [name, setName] = useState(userDetails.name || '');
    const [email, setEmail] = useState(userDetails.email || '');

    useEffect(() => {
        if (isFirstLogin) {
            navigate('/profile');
            // Store user details in Firestore
            const userDoc = doc(collection(firestore, 'users'), userDetails.id);
            setDoc(userDoc, userDetails)
                .then(() => {
                    console.log('User details successfully stored in Firestore');   
                })
                .catch((error) => {
                    console.error('Error storing user details: ', error);
                });
        }

        // Listen for real-time updates
        const userDoc = doc(collection(firestore, 'users'), userDetails.id);
        const unsubscribe = onSnapshot(userDoc, (doc) => {
            const data = doc.data();
            if (data) {
                setName(data.name);
                setEmail(data.email);
            }
        });

        return () => unsubscribe();
    }, [isFirstLogin, navigate, userDetails]);

    const handleSubmit = (e) => {
        e.preventDefault();
        const updatedUserDetails = { ...userDetails, name, email };
        const userDoc = doc(collection(firestore, 'users'), userDetails.id);
        setDoc(userDoc, updatedUserDetails)
            .then(() => {
                console.log('User details successfully updated in Firestore');
            })
            .catch((error) => {
                console.error('Error updating user details: ', error);
            });
    };

    return (
        <div>
            <h1>Profile Page</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>
                <button type="submit">Update Profile</button>
            </form>
        </div>
    );
};

export default Profile;
