import React from "react";
import { db } from "../firebaseConfig";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

const EmergencyButton = () => {
  const sendAlert = async () => {
    try {
      await addDoc(collection(db, "alerts"), {
        type: "Medical Emergency",
        timestamp: serverTimestamp(),
        location: { lat: 12.34, lng: 56.78 }, // Dynamic location
        status: "Active",
      });
      alert("Emergency Alert Sent!");
    } catch (error) {
      console.error("Error sending alert:", error);
    }
  };

  return (
    <button onClick={sendAlert} className="bg-red-500 text-white p-3 rounded">
      🚨 Send Emergency Alert
    </button>
  );
};

export default EmergencyButton;
