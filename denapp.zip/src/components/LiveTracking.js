import React, { useState, useEffect } from "react";
import { db } from "../firebaseConfig";
import { collection, onSnapshot } from "firebase/firestore";

const LiveTracking = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "alerts"), (snapshot) => {
      setAlerts(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });

    return () => unsub();
  }, []);

  return (
    <div>
      <h2>Live Emergency Alerts</h2>
      {alerts.map((alert) => (
        <div key={alert.id}>
          <p>Type: {alert.type}</p>
          <p>Location: {alert.location.lat}, {alert.location.lng}</p>
          <p>Status: {alert.status}</p>
        </div>
      ))}
    </div>
  );
};

export default LiveTracking;
