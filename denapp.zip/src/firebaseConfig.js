import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDVr4dcNV8jfynGxR4m3pQK8WW0byEeaWw",
  authDomain: "denapplication.firebaseapp.com",
  projectId: "denapplication",
  storageBucket: "denapplication.firebasestorage.app",
  messagingSenderId: "454542173311",
  appId: "1:454542173311:web:92fd6dbbabdb3504db0b4a",
  measurementId: "G-HM5H9JGLJC"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const provider = new GoogleAuthProvider();

export { app, auth, db, storage, provider, signInWithPopup, doc, getDoc, setDoc };





