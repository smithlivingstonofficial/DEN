import { ethers } from "ethers";

const contractAddress = "YOUR_SMART_CONTRACT_ADDRESS";
const abi = [
  {
    "inputs": [{ "internalType": "string", "name": "_alertType", "type": "string" }],
    "name": "logEmergency",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

export const logEmergency = async (alertType) => {
  if (window.ethereum) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, abi, signer);
    await contract.logEmergency(alertType);
  } else {
    console.log("Ethereum wallet not found");
  }
};
